/**
 * Event Controller
 * Handles event operations
 */

import { Event } from "../models/Event.js";
import { Booking } from "../models/Booking.js";

// Get all events
export const getEvents = async (req, res) => {
  try {
    const { status, date, dateFrom, includeInactive } = req.query;
    const filters = {};

    // By default, exclude inactive events for public access
    // Admin can pass includeInactive=true to see all events
    if (status) {
      filters.status = status;
    } else if (includeInactive !== 'true') {
      // Exclude inactive events by default
      filters.excludeInactive = true;
    }
    if (date) filters.date = date;
    if (dateFrom) filters.dateFrom = dateFrom;

    const events = await Event.findAll(filters);

    // Add available spots for each event
    const eventsWithSpots = await Promise.all(
      events.map(async (event) => {
        const availableSpots = await Event.getAvailableSpots(event.id);
        return {
          ...event,
          available_spots: availableSpots,
          booked_spots: event.max_players - availableSpots
        };
      })
    );

    res.json({
      success: true,
      events: eventsWithSpots
    });
  } catch (error) {
    console.error("Get events error:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching events"
    });
  }
};

// Get event by ID
export const getEventById = async (req, res) => {
  try {
    const { id } = req.params;
    const event = await Event.findById(id);

    if (!event) {
      return res.status(404).json({
        success: false,
        message: "Event not found"
      });
    }

    const availableSpots = await Event.getAvailableSpots(id);
    const bookings = await Booking.getEventBookingsByEvent(id);

    res.json({
      success: true,
      event: {
        ...event,
        available_spots: availableSpots,
        booked_spots: event.max_players - availableSpots,
        bookings_count: bookings.length
      }
    });
  } catch (error) {
    console.error("Get event by ID error:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching event"
    });
  }
};

// Admin: Create event
export const createEvent = async (req, res) => {
  try {
    const { name, description, date, time, max_players, price, location, image_url, hero_image_url, status } = req.body;

    // Validation
    if (!name || !date || !time) {
      return res.status(400).json({
        success: false,
        message: "Name, date, and time are required"
      });
    }

    const eventId = await Event.create({
      name,
      description,
      date,
      time,
      max_players: max_players || 20,
      price: price || 0,
      location,
      image_url: image_url || null,
      hero_image_url: hero_image_url || null,
      status: status || "active"
    });

    const event = await Event.findById(eventId);

    res.status(201).json({
      success: true,
      message: "Event created successfully",
      event
    });
  } catch (error) {
    console.error("Create event error:", error);
    res.status(500).json({
      success: false,
      message: "Error creating event"
    });
  }
};

// Admin: Update event (supports partial updates)
export const updateEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, date, time, max_players, price, location, image_url, hero_image_url, status } = req.body;

    console.log('📝 Update event request:', { id, body: req.body });

    const event = await Event.findById(id);
    if (!event) {
      console.error('❌ Event not found:', id);
      return res.status(404).json({
        success: false,
        message: "Event not found"
      });
    }

    console.log('✅ Found event:', event);

    // Helper: check if a string value is "provided" (not undefined, not null, not empty string)
    const isValidString = (val) => val !== undefined && val !== null && val !== '';
    
    // Helper: safely parse numeric value, returns null if invalid
    const parseNumeric = (val) => {
      if (val === undefined || val === null || val === '') return null;
      const num = Number(val);
      return isNaN(num) ? null : num;
    };

    // Build update object - only overwrite if valid value provided
    const updateData = {
      name: isValidString(name) ? name.trim() : event.name,
      description: description !== undefined ? (description || '') : event.description, // Allow empty string for description
      date: isValidString(date) ? date : event.date,
      time: isValidString(time) ? time : event.time,
      max_players: parseNumeric(max_players) !== null ? parseNumeric(max_players) : event.max_players,
      price: parseNumeric(price) !== null ? parseNumeric(price) : (event.price ? parseFloat(event.price) : 0),
      location: location !== undefined ? (location || '') : event.location, // Allow empty string for location
      image_url: image_url !== undefined ? (image_url || null) : event.image_url, // Allow clearing with empty string
      hero_image_url: hero_image_url !== undefined ? (hero_image_url || null) : event.hero_image_url, // Allow clearing with empty string
      status: isValidString(status) ? status : event.status
    };

    console.log('📤 Updating event with data:', updateData);

    const updated = await Event.update(id, updateData);

    if (!updated) {
      console.error('❌ Event.update returned false for ID:', id);
      return res.status(400).json({
        success: false,
        message: "Failed to update event - no rows affected"
      });
    }

    console.log('✅ Event.update successful, fetching updated event');

    const updatedEvent = await Event.findById(id);
    
    if (!updatedEvent) {
      console.error('❌ Could not fetch updated event:', id);
      return res.status(500).json({
        success: false,
        message: "Event updated but could not fetch updated data"
      });
    }

    console.log('✅ Event updated successfully:', updatedEvent);

    res.json({
      success: true,
      message: "Event updated successfully",
      event: updatedEvent
    });
  } catch (error) {
    console.error("❌ Update event error:", error);
    console.error("Error stack:", error.stack);
    res.status(500).json({
      success: false,
      message: error.message || "Error updating event",
      error: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
};

// Admin: Delete event
export const deleteEvent = async (req, res) => {
  try {
    const { id } = req.params;

    const event = await Event.findById(id);
    if (!event) {
      return res.status(404).json({
        success: false,
        message: "Event not found"
      });
    }

    const deleted = await Event.delete(id);

    if (!deleted) {
      return res.status(400).json({
        success: false,
        message: "Failed to delete event"
      });
    }

    res.json({
      success: true,
      message: "Event deleted successfully"
    });
  } catch (error) {
    console.error("Delete event error:", error);
    res.status(500).json({
      success: false,
      message: "Error deleting event"
    });
  }
};

// Book event
export const bookEvent = async (req, res) => {
  try {
    const { event_id } = req.body;
    const userId = req.user.id;

    if (!event_id) {
      return res.status(400).json({
        success: false,
        message: "Event ID is required"
      });
    }

    const event = await Event.findById(event_id);
    if (!event) {
      return res.status(404).json({
        success: false,
        message: "Event not found"
      });
    }

    if (event.status !== "active") {
      return res.status(400).json({
        success: false,
        message: "Event is not available for booking"
      });
    }

    // Check available spots
    const availableSpots = await Event.getAvailableSpots(event_id);
    if (availableSpots <= 0) {
      return res.status(400).json({
        success: false,
        message: "Event is fully booked"
      });
    }

    // Check if user already booked this event
    const existingBookings = await Booking.getEventBookingsByEvent(event_id);
    const userBooking = existingBookings.find(b => b.user_id === userId && b.status !== "cancelled");

    if (userBooking) {
      return res.status(400).json({
        success: false,
        message: "You have already booked this event"
      });
    }

    // Create booking
    const bookingId = await Booking.createEventBooking({
      event_id,
      user_id: userId,
      status: "pending",
      payment_status: "pending"
    });

    const booking = await Booking.getEventBookingById(bookingId);

    res.status(201).json({
      success: true,
      message: "Event booked successfully",
      booking
    });
  } catch (error) {
    console.error("Book event error:", error);
    res.status(500).json({
      success: false,
      message: "Error booking event"
    });
  }
};

// Cancel event booking
export const cancelEventBooking = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const booking = await Booking.getEventBookingById(id);
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found"
      });
    }

    if (booking.user_id !== userId) {
      return res.status(403).json({
        success: false,
        message: "You can only cancel your own bookings"
      });
    }

    if (booking.status === "cancelled") {
      return res.status(400).json({
        success: false,
        message: "Booking is already cancelled"
      });
    }

    const cancelled = await Booking.cancelEventBooking(id, userId);

    if (!cancelled) {
      return res.status(400).json({
        success: false,
        message: "Failed to cancel booking"
      });
    }

    res.json({
      success: true,
      message: "Booking cancelled successfully"
    });
  } catch (error) {
    console.error("Cancel event booking error:", error);
    res.status(500).json({
      success: false,
      message: "Error cancelling booking"
    });
  }
};

// Get user's event bookings
// Get all event bookings (admin only)
export const getAllEventBookings = async (req, res) => {
  try {
    const bookings = await Booking.getAllEventBookings();
    res.json({
      success: true,
      bookings
    });
  } catch (error) {
    console.error("Get all event bookings error:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching event bookings"
    });
  }
};

export const getMyEventBookings = async (req, res) => {
  try {
    const userId = req.user.id;
    const bookings = await Booking.getEventBookingsByUser(userId);

    res.json({
      success: true,
      bookings
    });
  } catch (error) {
    console.error("Get my event bookings error:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching bookings"
    });
  }
};

