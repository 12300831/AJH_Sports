/**
 * Database Migration Routes
 * These endpoints help fix database schema issues
 */

import express from 'express';
import pool from '../config/db.js';

const router = express.Router();

// Add missing columns to coaches table
router.post('/coaches-columns', async (req, res) => {
  let connection;
  
  try {
    console.log('🔧 Adding missing columns to coaches table...');
    
    connection = await pool.getConnection();
    
    // Check existing columns
    const [columns] = await connection.query(`
      SELECT COLUMN_NAME 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'coaches'
    `, [process.env.DB_NAME || 'ajh_sports']);
    
    const existingColumns = columns.map(col => col.COLUMN_NAME);
    const columnsToAdd = [];
    
    if (!existingColumns.includes('specialty')) {
      columnsToAdd.push({ name: 'specialty', type: 'VARCHAR(255)' });
    }
    
    if (!existingColumns.includes('availability')) {
      columnsToAdd.push({ name: 'availability', type: 'TEXT' });
    }
    
    if (columnsToAdd.length === 0) {
      return res.json({
        success: true,
        message: 'All required columns already exist',
        existingColumns
      });
    }
    
    // Add missing columns
    for (const col of columnsToAdd) {
      await connection.query(`ALTER TABLE coaches ADD COLUMN ${col.name} ${col.type}`);
      console.log(`✅ Added column: ${col.name}`);
    }
    
    connection.release();
    
    res.json({
      success: true,
      message: `Added ${columnsToAdd.length} column(s) to coaches table`,
      addedColumns: columnsToAdd.map(c => c.name)
    });
    
  } catch (error) {
    if (connection) connection.release();
    console.error('Migration error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
      code: error.code
    });
  }
});

export default router;
