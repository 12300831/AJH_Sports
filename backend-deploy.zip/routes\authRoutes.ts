import express from 'express';
import { signup, login } from '../controllers/authcontroller.js';

const router = express.Router();

// POST /api/auth/signup
router.post('/signup', signup);

// POST /api/auth/login
router.post('/login', login);

export default router;

